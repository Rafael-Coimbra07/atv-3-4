@extends('layouts.app')

@section('title', 'Criar Evento — FalaQ')

@section('content')
<div class="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md text-gray-900">
    <div class="mb-6">
        <h1 class="text-2xl font-bold text-gray-900">Criar novo evento</h1>
        <p class="mt-1 text-sm text-gray-600">Preencha os dados abaixo para cadastrar seu evento.</p>
    </div>

    <form action="{{ route('eventos.store') }}" method="POST" class="space-y-5">
        @csrf

        <div>
            <label for="titulo" class="block text-sm font-medium text-gray-700 mb-2">
                Título do evento
            </label>
            <input
                type="text"
                name="titulo"
                id="titulo"
                value="{{ old('titulo') }}"
                class="w-full rounded-md border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 @error('titulo') border-red-500 focus:border-red-500 focus:ring-red-200 @enderror"
                placeholder="Digite o título do evento"
            >
            @error('titulo')
                <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="descricao" class="block text-sm font-medium text-gray-700 mb-2">
                Descrição do evento
            </label>
            <textarea
                name="descricao"
                id="descricao"
                rows="5"
                class="w-full rounded-md border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 @error('descricao') border-red-500 focus:border-red-500 focus:ring-red-200 @enderror"
                placeholder="Descreva o seu evento"
            >{{ old('descricao') }}</textarea>
            @error('descricao')
                <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <div>
            <label for="data_evento" class="block text-sm font-medium text-gray-700 mb-2">
                Data do evento
            </label>
            <input
                type="date"
                name="data_evento"
                id="data_evento"
                value="{{ old('data_evento') }}"
                class="w-full rounded-md border border-gray-300 px-4 py-2.5 text-gray-900 shadow-sm outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 @error('data_evento') border-red-500 focus:border-red-500 focus:ring-red-200 @enderror"
            >
            @error('data_evento')
                <p class="mt-1 text-sm text-red-500">{{ $message }}</p>
            @enderror
        </div>

        <button
            type="submit"
            class="w-full rounded-md bg-blue-600 px-4 py-2.5 font-semibold text-white transition hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
        >
            Criar evento
        </button>
    </form>
</div>
@endsection
